class TabBarViewModel {
  final List<String> tabTitles;

  TabBarViewModel({
    required this.tabTitles,
  });
}