package com.example.designsystemsampleapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
